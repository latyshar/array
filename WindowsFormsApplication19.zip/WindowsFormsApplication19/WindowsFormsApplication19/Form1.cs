﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication19
{
    public partial class Form1 : Form
    {
        int n, m, i, j;
        int sum = 0;
        int[] mas;
        int[] mas2;
        int[] mas3;

        Random rnd = new Random();
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView2.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        private void button4_Click(object sender, EventArgs e)
        {

            int min = mas[0];
            int minPos = 0;

            for (int i = 0; i < n; ++i)
            {
                if (min < mas[i]) continue;
                min = mas[i];
                minPos = i;
            }

            if (minPos != (n - 1))
            {
                double product = 1;
                for (int i = minPos + 1; i < n; ++i)
                {
                    product *= mas[i];
                }

                dataGridView1[minPos, 0].Style.BackColor = Color.Green;
                textBox4.Text = product.ToString();
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            m = Convert.ToInt32(numericUpDown2.Value);
            this.dataGridView2.ColumnCount = m;
         
            mas2 = new int[m];
            

            for (i = 0; i < m; i++)
            {
                mas2[i] = rnd.Next(1, 14);
                dataGridView2.Rows[0].Cells[i].Value = mas2[i].ToString();

            }

        }

        private void button6_Click(object sender, EventArgs e)
        {
            string str2 = "";
            mas3 = mas.Concat(mas2).ToArray();

            for (i = 0; i < mas3.Length; i++)
                str2 += mas3[i].ToString() + " ";
            this.textBox6.Text = str2;
         

        }

       private void button3_Click(object sender, EventArgs e)
        {
            string str = "";
            for (int i = mas.Length - 1; i >= 0; i--)
            {
                str += mas[i].ToString() + " ";
                this.textBox5.Text = str;
               
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
       
            n = Convert.ToInt32(numericUpDown1.Value);
            this.dataGridView1.ColumnCount = n;
   
            mas = new int[n];

            for (i=0; i<n; i++)
            {
                mas[i] = rnd.Next(1, 10);
                dataGridView1.Rows[0].Cells[i].Value = mas[i].ToString();
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            var x = Convert.ToInt32(textBox1.Text);
            var y = Convert.ToInt32(textBox2.Text);

            for (int i = 0; i < mas.Length; i++)

                if (i > x)
                { 
                    if (i < y)
                    { 
                    sum += mas[i];
                    }
                    
                    textBox3.Text = sum.ToString();

                }
      
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private void label8_Click(object sender, EventArgs e)
        {

        }
    }
}
